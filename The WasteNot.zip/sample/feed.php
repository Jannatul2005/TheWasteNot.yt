<?php
$connection = mysqli_connect("localhost:3306", "root", "");
$db = mysqli_select_db($connection, 'demo');
include "../connection.php";
include("connect.php");

// Check connection
if ($connection->connect_error) {
    die("Connection failed: " . $connection->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Form validation
    $name = test_input($_POST["name"]);
    $email = test_input($_POST["email"]);
    $message = test_input($_POST["message"]);

    if (empty($name) || empty($email) || empty($message)) {
        $error_message = "All fields are required!";
    } else {
        // Insert feedback into the database
        $insert_query = "INSERT INTO user_feedback (name, email, message) VALUES ('$name', '$email', '$message')";

        if ($connection->query($insert_query) === TRUE) {
            $success_message = "Feedback sent successfully!";
        } else {
            $error_message = "Error: " . $connection->error;
        }
    }
}

function test_input($data)
{
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Feedback</title>

    <style>
        body {
            
            background-image: url('p.jpg'); /* Set the background image */
            background-size: cover; /* Cover the entire viewport with the background image */
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100vh;
            margin: 0;
        }

        .feedback-container {
            background-color: #ffffff; /* Set a contrasting background color for the feedback container */
            border-radius: 10px; /* Add border radius for a rounded look */
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1); /* Add a subtle box shadow */
            padding: 20px;
            width: 500px; /* Set the desired width of the feedback container */
        }

        .heading {
            text-align: center;
            margin-bottom: 20px;
        }

        .contact-form {
            margin-bottom: 20px;
        }

        .contact-info {
            padding: 10px;
            text-align: center;
        }

        label {
            display: block;
            margin-bottom: 5px;
        }

        input,
        textarea {
            width: 100%;
            padding: 8px;
            margin-bottom: 10px;
            box-sizing: border-box;
        }

        input[type="submit"] {
            background-color: #4caf50; /* Set a nice color for the submit button */
            color: #fff;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #45a049; /* Darken the color on hover */
        }

        .error {
            color: red;
        }

        .success {
            color: green;
        }
    </style>
</head>

<body>
    <div class="feedback-container">
        <p class="heading">Feedback</p>

        <div class="contact-form">
            <?php
            if (isset($error_message)) {
                echo '<p class="error">' . $error_message . '</p>';
            } elseif (isset($success_message)) {
                echo '<p class="success">' . $success_message . '</p>';
            }
            ?>

            <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                <label for="name">Name:</label>
                <input type="text" id="name" name="name" required>
                <label for="email">Email:</label>
                <input type="email" id="email" name="email" required>
                <label for="message">Message:</label>
                <textarea id="message" name="message" required></textarea>
                <input type="submit" value="Send" name="send">
                <button type="button" onclick="goToHome()">Back</button>

            <script>
                function goToHome() {
                    window.location.href = "home.html";
                }

                function onSubmit() {
                    
                    return true; // return true to allow the form to be submitted
                }
            </script>
            </form>
        </div>

        <div class="contact-info">
            <p>Email: wastenot@gmail.com</p>
            <p>Phone: (+880) 1888 888 888</p>
            <p>Address: Green University of Bangladesh</p>
        </div>
    </div>
</body>

</html>
