-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Jan 09, 2024 at 04:20 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `demo`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `Aid` int(11) NOT NULL,
  `name` text NOT NULL,
  `email` varchar(60) DEFAULT NULL,
  `password` text NOT NULL,
  `location` text NOT NULL,
  `address` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`Aid`, `name`, `email`, `password`, `location`, `address`) VALUES
(5, 'jannatul', 'jannatul@gmail.com', '$2y$10$NFVwLGL1n1lz.c3gL3YVpuNSDO39x8MMR/ed5bAfx4OFLrz0fdn7y', 'Dhaka', 'Dhanmondi'),
(6, 'Fardin', 'Fardin@gmail.com', '$2y$10$bZ1oTZTqwGnY6RA2a2ug8.J9Tb59lVxlemzbycT5Yv9.NXqUmK.gO', 'Dhaka', 'Mirpur,1216');

-- --------------------------------------------------------

--
-- Table structure for table `delivered`
--

CREATE TABLE `delivered` (
  `ngo` varchar(20) NOT NULL,
  `quantity` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `delivered`
--

INSERT INTO `delivered` (`ngo`, `quantity`) VALUES
('biddanondo', 50),
('asha', 40),
('asha', 23),
('unnoto', 20),
('asha', 5),
('briks', 4),
('abc', 24),
('fjnk', 3),
('asdf', 5),
('bonton', 34),
('onno', 10),
('bonton', 30);

-- --------------------------------------------------------

--
-- Table structure for table `delivery_persons`
--

CREATE TABLE `delivery_persons` (
  `Did` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `city` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `delivery_persons`
--

INSERT INTO `delivery_persons` (`Did`, `name`, `email`, `password`, `city`) VALUES
(7, 'nuri', 'nuri@gmail.com', '$2y$10$JmQNuFpSLyFdXIyOFaIclOWfhFpxLomIzd7hoNWgkpw0BPD2SXGYG', 'Jashore'),
(8, 'Fardin Khan', 'fardin1234@gmail.com', '$2y$10$YGnySJP/5h8/ybUelt8vJuE2NxUGoAQjssE03RxXL0s5AWbpNq8Wu', 'Dhaka');

-- --------------------------------------------------------

--
-- Table structure for table `donations`
--

CREATE TABLE `donations` (
  `Fid` int(11) NOT NULL,
  `name` varchar(20) NOT NULL,
  `type` varchar(255) DEFAULT NULL,
  `payment_method` varchar(20) NOT NULL,
  `amount` decimal(10,2) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `phoneno` int(11) DEFAULT NULL,
  `date` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `donations`
--

INSERT INTO `donations` (`Fid`, `name`, `type`, `payment_method`, `amount`, `email`, `phoneno`, `date`) VALUES
(2, 'KM', 'National', 'nagad', 2345.00, 'km12@gmail.com', 1334455657, '2024-01-05 17:52:46'),
(3, 'KM', 'National', 'rocket', 1000.00, 'km12@gmail.com', 1334455657, '2024-01-05 18:23:16'),
(4, 'KM', 'National', 'rocket', 2000.00, 'km12@gmail.com', 1534567890, '2024-01-05 18:23:58'),
(5, 'KM', 'National', 'rocket', 1000.00, 'km12@gmail.com', 1334455657, '2024-01-05 18:50:28'),
(6, 'KM', 'National', 'nagad', 1000.00, 'km12@gmail.com', 1999999999, '2024-01-05 18:51:21'),
(7, 'KM', 'National', 'bkash', 1000.00, 'km12@gmail.com', 1334455657, '2024-01-05 19:04:28'),
(8, 'KM', 'National', 'bkash', 50000.00, 'km12@gmail.com', 1665544321, '2024-01-05 19:32:33'),
(9, 'KM', 'National', 'nagad', 30000.00, 'km12@gmail.com', 1334455657, '2024-01-05 19:35:53'),
(10, 'KM', 'National', 'bkash', 4000.00, 'km12@gmail.com', 1334455657, '2024-01-05 22:32:24'),
(11, 'KM', 'National', 'bkash', 234567.00, 'km12@gmail.com', 1334455657, '2024-01-06 12:03:33'),
(12, 'abc', 'National', 'rocket', 800.00, 'abc@gmail.com', 1334455657, '2024-01-06 13:51:49'),
(13, 'KM', 'National', 'nagad', 40000.00, 'km12@gmail.com', 1334455657, '2024-01-07 14:43:14'),
(14, 'KM', 'National', 'nagad', 30000.00, 'km12@gmail.com', 1334455657, '2024-01-07 15:49:35'),
(15, 'KM', 'National', 'rocket', 70000.00, 'km12@gmail.com', 1334455656, '2024-01-07 16:05:25'),
(16, 'KM', 'National', 'rocket', 60000.00, 'km12@gmail.com', 1334455657, '2024-01-07 20:08:07'),
(17, 'KM', 'National', 'nagad', 90000.00, 'km12@gmail.com', 1334455658, '2024-01-07 20:22:30');

-- --------------------------------------------------------

--
-- Table structure for table `food_donations`
--

CREATE TABLE `food_donations` (
  `Fid` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(60) NOT NULL,
  `food` varchar(50) NOT NULL,
  `type` text NOT NULL,
  `category` text NOT NULL,
  `quantity` text NOT NULL,
  `date` datetime DEFAULT current_timestamp(),
  `address` text NOT NULL,
  `location` varchar(50) NOT NULL,
  `phoneno` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `food_donations`
--

INSERT INTO `food_donations` (`Fid`, `name`, `email`, `food`, `type`, `category`, `quantity`, `date`, `address`, `location`, `phoneno`) VALUES
(30, 'KM', 'km@gmail.com', 'Beef', 'Non-veg', 'cooked-food', '2', '2023-12-06 00:43:35', 'Mirpur', 'Dhaka', '0188888888'),
(31, 'KM', 'km@gmail.com', 'Potato', 'veg', 'raw-food', '9', '2023-12-06 00:46:55', 'Mirpur', 'Dhaka', '0188888888'),
(36, 'KM', 'km12@gmail.com', 'mula', 'veg', 'raw-food', '5', '2023-12-16 01:47:23', 'Gulshan, 19/b', 'Dhaka', '01334455657'),
(37, 'KM', 'km12@gmail.com', 'Meat', 'Non-veg', 'cooked-food', '12', '2023-12-16 01:52:06', 'mirpur, dohs, 19/b', 'Dhaka', '01234567890'),
(38, 'MD. Fardin', 'km12@gmail.com', 'curry', 'Non-veg', 'raw-food', '15', '2023-12-16 01:57:46', 'Gulshan, 19/b', 'Dhaka', '01888888880'),
(39, 'MD. Fardin', 'fardin1@gmail.com', 'curry', 'veg', 'raw-food', '4', '2023-12-23 22:57:27', 'mirpur, dohs, 19/b', 'Dhaka', '01888888880'),
(40, 'MD. Fardin', 'fardin1@gmail.com', 'Duck@', 'Non-veg', 'cooked-food', '7', '2023-12-23 23:29:33', 'Gulshan, 19/b', 'Dhaka', '01999999999'),
(41, 'MD. Fardin', 'fardin1@gmail.com', 'curry', 'Non-veg', 'raw-food', '10', '2023-12-23 23:44:16', 'Mirpur', 'Dhaka', '01334455657'),
(42, 'MD. Fardin', 'fardin1@gmail.com', 'Meat', 'Non-veg', 'packed-food', '6', '2023-12-24 00:07:24', 'mirpur, dohs, 19/b', 'Dhaka', '01999999999'),
(43, 'KM', 'km12@gmail.com', 'Meat', 'Non-veg', 'packed-food', '7', '2023-12-24 22:12:23', 'Gulshan, 19/b', 'Dhaka', '01334455657'),
(44, 'Fardin', 'Fardin@gmail.com', 'Meat', 'Non-veg', 'cooked-food', '4', '2023-12-24 22:27:12', 'mirpur, dohs, 19/b', 'Dhaka', '01999999999'),
(45, 'Fardin', 'Fardin@gmail.com', 'duck', 'Non-veg', 'packed-food', '10', '2023-12-24 22:39:38', 'mirpur, dohs, 19/b', 'Jashore', '01334455657'),
(46, 'Fardin', 'Fardin@gmail.com', 'mula', 'veg', 'raw-food', '6', '2023-12-25 00:28:13', 'Gulshan, 19/b', 'Chittagong', '01334455657'),
(47, 'Fardin', 'Fardin@gmail.com', 'Meat', 'veg', 'raw-food', '9', '2023-12-25 00:28:44', 'Mirpur', 'Jashore', '01334455657'),
(48, 'KM', 'km12@gmail.com', 'mula', 'veg', 'raw-food', '10', '2023-12-26 21:24:33', 'mirpur, dohs, 19/b', 'Dhaka', '01334455657'),
(49, 'KM', 'km12@gmail.com', 'Meat', 'Non-veg', 'cooked-food', '10', '2024-01-04 21:03:41', 'Gulshan, 19/b', 'Dhaka', '01334455657'),
(50, 'KM', 'km12@gmail.com', 'rice', 'Non-veg', 'raw-food', '17', '2024-01-04 21:04:49', 'Gulshan, 19/b', 'Dhaka', '01334455657'),
(51, 'KM', 'km12@gmail.com', 'mula', 'veg', 'raw-food', '2', '2024-01-04 21:05:31', 'Mirpur', 'Dhaka', '01334455657'),
(52, 'KM', 'km12@gmail.com', 'curry', 'veg', 'raw-food', '14', '2024-01-05 11:55:25', 'mirpur, dohs, 19/b', 'Dhaka', '01334455657'),
(53, 'KM', 'km12@gmail.com', 'Meat', 'veg', 'packed-food', '27', '2024-01-05 22:34:44', 'mirpur, dohs, 19/b', 'Chittagong', '01999999999'),
(54, 'nuri', 'nuri@gmail.com', 'Meat', 'veg', 'packed-food', '6', '2024-01-06 13:19:18', 'mirpur, dohs, 19/b', 'Jashore', '01334455657'),
(55, 'KM', 'km12@gmail.com', 'Meat', 'Non-veg', 'packed-food', '22', '2024-01-07 14:42:18', 'Gulshan, 19/b', 'Cumilla', '01334455657'),
(56, 'KM', 'km12@gmail.com', 'Meat', 'veg', 'packed-food', '10', '2024-01-07 15:48:06', 'mirpur, dohs, 19/b', 'Cumilla', '01334455657'),
(57, 'KM', 'km12@gmail.com', 'Curry', 'veg', 'cooked-food', '12', '2024-01-07 16:04:10', 'Gulshan, 19/b', 'Jashore', '01334455656'),
(58, 'KM', 'km12@gmail.com', 'Mutton', 'Non-veg', 'cooked-food', '36', '2024-01-07 20:06:51', 'Gulshan, 19/b', 'Jashore', '01334455657'),
(59, 'KM', 'km12@gmail.com', 'Mutton', 'Non-veg', 'cooked-food', '27', '2024-01-07 20:21:34', 'mirpur, dohs, 19/b', 'Jashore', '01334455657'),
(60, 'KM', 'km12@gmail.com', 'Meat', 'Non-veg', 'raw-food', '12', '2024-01-09 21:11:31', 'Gulshan, 19/b', 'Chittagong', '01334455657');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `id` int(11) NOT NULL,
  `name` text NOT NULL,
  `email` varchar(60) NOT NULL,
  `phoneno` varchar(15) DEFAULT NULL,
  `password` text NOT NULL,
  `gender` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`id`, `name`, `email`, `phoneno`, `password`, `gender`) VALUES
(26, 'abc', 'abc@gmail.com', '01999999999', '$2y$10$XitTmA3RdKg.oC5j7lyFPOw4TrDsEDfWni5qvZTRWim8uUe4/60wy', 'male'),
(23, 'MD. Fardin', 'fardin1@gmail.com', NULL, '$2y$10$DHEG0VPTQJFYBNrJh2N9jOk/pSpHMMUqdQi67gcOth.GBidSzZ1.W', 'male'),
(31, 'abcdef', 'fardin201@gmail.com', '01999999999', '$2y$10$XFCW9OkNWHHwCqwUIuwJ7OUfrCyB4JwsKCSPBLLoS98dr25bx8Lly', 'male'),
(32, 'abcdef', 'fardin20@gmail.com', '01999999999', '$2y$10$QQAO59DWwzzxmPGHooRW2uIvFXbzQPdvTGdPASNf0pyfPijKGim.S', 'male'),
(30, 'lkjhgfdsaw', 'fardin21@gmail.com', '01999999999', '$2y$10$PjdPqoRm3ZjgtfjCh7/XwO0wrIH90LMUjMz2KcZBFnmT9eXnO2dJ.', 'male'),
(29, 'lkjhgfdsaw', 'fardin31@gmail.com', '01999999999', '$2y$10$P27xp2bF1rrSqzw0rTJDku59Jk0hzkhgraYUcpTDjvX0mUZzYMW8K', 'male'),
(21, 'fardin', 'fardin@gmail', NULL, '$2y$10$bnyXL.0PkPx1DuwZrqMfz.2LtxMisGIngYlIP7o9fsr0gxgfO5xhm', 'male'),
(28, 'gardin', 'fardin@gmail.com', '01999999999', '$2y$10$xIbJDZb8KGhB.SPQ6PWE1eN2dis6UBIHvwW13OHkRvT.tIAKP.TS6', 'male'),
(27, 'khan', 'jannatul@gmail.com', '01888888880', '$2y$10$mZqI1ri4dBE4A7kj7bTWbukA5vdpkvHlHdcpsGESTDv6Nje171HLy', 'female'),
(22, 'KM', 'km12@gmail.com', NULL, '$2y$10$oFS2JCf4HW6b6MknAatEmOS.AKTxzrqBwUEf1EUYei9LlKf8XnFEG', 'male'),
(20, 'KM', 'km@gmail.com', NULL, '$2y$10$YDRpTBuLZYuVVYc9AGpwJ.C0z5RcuCqogQIenjHyjyj4ZwJGEFkA2', 'male');

-- --------------------------------------------------------

--
-- Table structure for table `user_feedback`
--

CREATE TABLE `user_feedback` (
  `feedback_id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `message` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_feedback`
--

INSERT INTO `user_feedback` (`feedback_id`, `name`, `email`, `message`) VALUES
(1, 'John Smith', 'john@example.com', 'I really enjoyed using your product!'),
(2, 'prasanna', 'bprasanna0502@gmail.com', 'good'),
(3, 'prasanna', 'bprasanna0502@gmail.com', 'liked it'),
(4, 'prasanna', 'bprasanna0502@gmail.com', 'great'),
(5, 'abi', 'bsabineshakash@gmail.com', 'great'),
(6, 'arun', 'arun26ifs@gmail.com', 'not good'),
(7, 'abc', 'fardin1234@gmail.com', 'not standard'),
(8, 'janantul', 'jannatul@gmail.com', 'need to update more'),
(9, 'Fardin Khan', 'b@gmail.com', 'Overall good'),
(10, 'MD. Fardin', 'fardin1234@gmail.com', 'so good'),
(11, 'Jannatul', 'jannatul@gmail.com', 'Very much perfect'),
(12, 'MD. Fardin', 'fardin1234@gmail.com', 'good but need more update'),
(13, 'MD. Fardin', 'Fardin@gmail.com', 'Overall Good');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`Aid`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `delivery_persons`
--
ALTER TABLE `delivery_persons`
  ADD PRIMARY KEY (`Did`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `donations`
--
ALTER TABLE `donations`
  ADD PRIMARY KEY (`Fid`);

--
-- Indexes for table `food_donations`
--
ALTER TABLE `food_donations`
  ADD PRIMARY KEY (`Fid`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`email`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `user_feedback`
--
ALTER TABLE `user_feedback`
  ADD PRIMARY KEY (`feedback_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `Aid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `delivery_persons`
--
ALTER TABLE `delivery_persons`
  MODIFY `Did` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `donations`
--
ALTER TABLE `donations`
  MODIFY `Fid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `food_donations`
--
ALTER TABLE `food_donations`
  MODIFY `Fid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=61;

--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `user_feedback`
--
ALTER TABLE `user_feedback`
  MODIFY `feedback_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
