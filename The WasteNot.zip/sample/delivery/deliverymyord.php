<?php
session_start();
$connection = mysqli_connect("localhost:3306", "root", "");
$db = mysqli_select_db($connection, 'demo');

if (isset($_POST['submit'])) {
    $ngo_name = mysqli_real_escape_string($connection, $_POST['ngo_name']);
    $delivered_quantity = mysqli_real_escape_string($connection, $_POST['delivered_quantity']);

    $query = "INSERT INTO delivered (ngo, quantity) VALUES ('$ngo_name', '$delivered_quantity')";

    $query_run = mysqli_query($connection, $query);

    if ($query_run) {
        echo '<script type="text/javascript">
                alert("Data saved successfully");
                window.location.href = "http://localhost/sample/delivery/delivery.php";
              </script>';
    } else {
        echo '<script type="text/javascript">alert("Data not saved")</script>';
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Food Donate</title>
    <link rel="stylesheet" href="loginstyle.css">

    <style>
        body {
            background-image: url('5.jpg');
            background-size: cover; 
            background-repeat: no-repeat; 
            background-attachment: fixed; 
        }
    </style>
</head>
<body style="background-color: #06C167;">
    <div class="container">
        <div class="regformf">
            <form action="" method="post">
                <div class="input">
                    <label for="ngo_name">Enter NGO Name:</label>
                    <input type="text" id="ngo_name" name="ngo_name" required />
                </div>

                <div class="input">
                    <label for="delivered_quantity">Enter Delivered Quantity (Kg):</label>
                    <input type="numeric" id="delivered_quantity" name="delivered_quantity" required />
                </div>

                <div class="btn submit-btn">
                    <button type="submit" name="submit">Donate</button>
                </div>
            </form>
        </div>
    </div>
</body>
</html>
