<?php
include("login.php"); 
if($_SESSION['name']==''){
	header("location: signin.php");
}
include("login.php"); 
$emailid= $_SESSION['email'];
$connection=mysqli_connect("localhost:3306","root","");
$db=mysqli_select_db($connection,'demo');
if(isset($_POST['submit']))
{
    $meal=mysqli_real_escape_string($connection, $_POST['meal']);
    $payment_method=mysqli_real_escape_string($connection, $_POST['payment_method']);
    $phoneno=mysqli_real_escape_string($connection, $_POST['phoneno']);
    $amount=mysqli_real_escape_string($connection, $_POST['amount']);
    $email=mysqli_real_escape_string($connection, $_POST['email']);
    $name=mysqli_real_escape_string($connection, $_POST['name']);
    if (!preg_match('/^(013|014|015|016|017|018|019)\d{8}$/', $phoneno)) {
        echo "<h1><center style='color: white;'>Invalid phone number format</center></h1>";
    } else {
        $query = "INSERT INTO donations (type, payment_method, phoneno, amount, email, name) 
        VALUES ('$meal', '$payment_method', '$phoneno', '$amount', '$emailid', '$name')";

        $query_run= mysqli_query($connection, $query);
        if($query_run)
        {
            echo '<script type="text/javascript">
                    alert("Donation successfull");
                    window.location.href = "profile.php";
                  </script>';
        }
        else {
            echo '<script type="text/javascript">alert("Data not saved")</script>';
        }
    }
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Food Donate</title>
    <link rel="stylesheet" href="loginstyle.css">

    <style>
        body {
            background-image: url('p.jpg');
            background-size: cover; 
            background-repeat: no-repeat; 
            background-attachment: fixed; 
        }
        .submit-btn {
            display: none;
        }
    </style>

    <script>
        function generateAndShowOtp() {
            var generatedOtp = Math.floor(1000 + Math.random() * 9000);
            alert('OTP sent successfully. Your OTP is: ' + generatedOtp);
            document.getElementById('generated_otp').value = generatedOtp;
        }

        function verifyotp() {
            var enteredOtp = document.getElementById('otp').value;
            var generatedOtp = document.getElementById('generated_otp').value;

            if (enteredOtp === generatedOtp) {
                alert('OTP verification successful');
                // Show the submit button
                document.querySelector('.submit-btn').style.display = 'block';
            } else {
                alert('Invalid OTP. Please try again.');
                // Hide the submit button if OTP is invalid
                document.querySelector('.submit-btn').style.display = 'none';
            }
        }
    </script>
</head>
<body style="background-color: #06C167;">
    <div class="container">
        <div class="regformf">
            <form action="" method="post">
                <p class="logo"> <b style="color: black;">Money</b> <b style="color: #06C167; ">Donation</b></p>

                <div class="radio">
                    <label for="meal" >Payment Type :</label> 
                    <br><br>
                    <input type="radio" name="meal" id="National" value="National" required/>
                    <label for="National" style="padding-right: 40px;">National</label>
                    <input type="radio" name="meal" id="International" value="International" >
                    <label for="International">International</label>
                </div>
                <br>
                <div class="input">
                    <label for="payment_method">Select Payment Method:</label>
                    <select id="payment_method" name="payment_method" required>
                        <option value="bkash">bKash</option>
                        <option value="nagad">Nagad</option>
                        <option value="rocket">Rocket</option>
                    </select>
                </div>

                <br>
                <div class="input">
                    <label for="phoneno">Account Number:</label>
                    <input type="text" id="phoneno" name="phoneno" maxlength="11" pattern="[0-9]{11}" required />
                </div>
                
                <div class="input">
                    <label for="amount">Amount (TK):</label>
                    <input type="numeric" id="amount" name="amount" required>
                </div>
                <div class="input">
                    <label for="pin">Pin:</label>
                    <input type="password" id="password" name="password" required>
                </div>
                <!-- Add these elements after the Pin input -->
                <div class="input">
                <label for="otp">OTP:</label>
                <input type="numeric" id="otp" name="otp" required>
                </div>
                <div class="btn">
                    <button type="button" onclick="generateAndShowOtp()">Send OTP</button>
                </div>
                <div class="btn">
                    <button type="button" onclick="verifyotp()">Verify OTP</button>
                </div>
               

                <b><p style="text-align: center;">Contact Details</p></b>
                <div class="input">
                    <div>
                        <label for="email">Email:</label>
                        <input type="email" id="email" name="email" value="<?php echo"". $_SESSION['email'] ;?>" required/>
                    </div>
                    <div>
                        <label for="name">Name:</label>
                        <input type="text" id="name" name="name" value="<?php echo"". $_SESSION['name'] ;?>" required/>
                    </div>

                    <div class="btn submit-btn">
                        <button type="submit" name="submit"> Donate</button>
                    </div>

                    <input type="hidden" id="generated_otp" name="generated_otp" value="">
            </form>
        </div>
    </div>

    

</body>
</html>
