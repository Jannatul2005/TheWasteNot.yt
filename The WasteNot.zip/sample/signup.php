
<?php
include 'connection.php';
$connection = mysqli_connect("localhost:3306", "root", "");
$db = mysqli_select_db($connection, 'demo');

if (isset($_POST['sign'])) {
    $username = mysqli_real_escape_string($connection, $_POST['name']);
    $email = mysqli_real_escape_string($connection, $_POST['email']);
    $phoneno = mysqli_real_escape_string($connection, $_POST['phoneno']);
    $password = mysqli_real_escape_string($connection, $_POST['password']);
    $gender = mysqli_real_escape_string($connection, $_POST['gender']);

    // Validate Name
    if (!preg_match('/^[a-zA-Z]{1,10}$/', $username)) {
        echo "<h1><center>Invalid name format</center></h1>";
    } else if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        // Validate Email
        echo "<h1><center>Invalid email format</center></h1>";
    } else if (strlen($password) < 8 || !preg_match('/[0-9]/', $password) || !preg_match('/[^a-zA-Z0-9]/', $password)) {
        // Validate Password
        echo "<h1><center>Invalid password format</center></h1>";
    } else if (!preg_match('/^(013|014|015|016|017|018|019)\d{8}$/', $phoneno)) {
        // Validate Phone Number
        echo "<h1><center>Invalid phone number format</center></h1>";
    } else {
        // Hash the password
        $pass = password_hash($password, PASSWORD_DEFAULT);

        // Check if the email already exists
        $sql = "SELECT * FROM login WHERE email='$email'";
        $result = mysqli_query($connection, $sql);
        $num = mysqli_num_rows($result);

        if ($num > 0) {
            echo "<h1><center>Account already exists</center></h1>";
        } else {
            // Use prepared statement to prevent SQL injection
            $query = "INSERT INTO login (name, email, phoneno, password, gender) VALUES (?, ?, ?, ?, ?)";
            $stmt = mysqli_prepare($connection, $query);
            mysqli_stmt_bind_param($stmt, "sssss", $username, $email, $phoneno, $pass, $gender);

            if (mysqli_stmt_execute($stmt)) {
                header("location: signin.php");
                exit();
            } else {
                echo '<h1><center>Data not saved</center></h1>';
            }

            // Close the statement
            mysqli_stmt_close($stmt);
        }
    }

    // Close the database connection
    mysqli_close($connection);
}
?>

<DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="loginstyle.css">
    <link rel="stylesheet" href="path/to/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.3.0/font/bootstrap-icons.css" />
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css">
    <style>
        body {
            background-image: url('5.jpg');
            background-size: cover; 
            background-repeat: no-repeat; 
            background-attachment: fixed; 
        }

    </style>
    
</head>
<body>
    <div class="container">
        <div class="regform">
            <form action="" method="post">
                <p class="logo">The <b style="color: #06C167;">WasteNot</b></p>
                <p id="heading">Create your account</p>
                
                <div class="input">
                    <label class="textlabel" for="name">User name</label><br>
                    <input type="text" id="name" name="name" value="<?php echo isset($_POST['name']) ? htmlspecialchars($_POST['name']) : ''; ?>" required/>
                    <div id="name-msg" class="validation-msg"></div>
                </div>
                
                <div class="input">
                    <label class="textlabel" for="email">Email</label>
                    <input type="email" id="email" name="email" value="<?php echo isset($_POST['email']) ? htmlspecialchars($_POST['email']) : ''; ?>" required/>
                    <div id="email-msg" class="validation-msg"></div>

                    <label class="textlabel" for="phoneno">Phone no</label>
                    <input type="text" id="phoneno" name="phoneno" value="<?php echo isset($_POST['phoneno']) ? htmlspecialchars($_POST['phoneno']) : ''; ?>" />
                </div>

                <label class="textlabel" for="password">Password</label>
                <div class="password">
                    <input type="password" name="password" id="password" value="<?php echo isset($_POST['password']) ? htmlspecialchars($_POST['password']) : ''; ?>" required/>
                    <i class="uil uil-eye-slash showHidePw" id="showpassword"></i>
                </div>

                <div class="radio">
                    <input type="radio" name="gender" id="male" value="male" <?php echo (isset($_POST['gender']) && $_POST['gender'] == 'male') ? 'checked' : ''; ?> required/>
                    <label for="male">Male</label>

                    <input type="radio" name="gender" id="female" value="female" <?php echo (isset($_POST['gender']) && $_POST['gender'] == 'female') ? 'checked' : ''; ?> />
                    <label for="female">Female</label>
                </div>

                <div class="btn">
                    <button type="submit" name="sign">Continue</button>
                    <button type="back" name="back"><a href="home.html">Back </a></button>
                </div>
                
                <div class="signin-up">
                    <p style="font-size: 20px; text-align: center;">Already have an account? <a href="signin.php">Sign in</a></p>
                </div>
            </form>
        </div>
    </div>
    <script src="login.js"></script>
   


    <script>
        document.addEventListener('DOMContentLoaded', function () {
            var nameInput = document.getElementById('name');
            var emailInput = document.getElementById('email');

            nameInput.addEventListener('input', function () {
                validateName();
            });

            emailInput.addEventListener('input', function () {
                validateEmail();
            });

            function validateName() {
                var nameMsg = document.getElementById('name-msg');
                if (nameInput.validity.valueMissing) {
                    nameMsg.innerHTML = 'Please enter your name';
                } else if (!nameInput.validity.patternMismatch) {
                    nameMsg.innerHTML = 'Consider providing a name with 1 to 10 characters containing only letters';
                } else {
                    nameMsg.innerHTML = '';
                }
            }

            function validateEmail() {
                var emailMsg = document.getElementById('email-msg');
                if (emailInput.validity.valueMissing) {
                    emailMsg.innerHTML = 'Please enter your email';
                } else if (!emailInput.validity.valid) {
                    emailMsg.innerHTML = 'Please check your email format for correctness';
                } else {
                    emailMsg.innerHTML = '';
                }
            }
        });
       

    </script>
</body>
</html>