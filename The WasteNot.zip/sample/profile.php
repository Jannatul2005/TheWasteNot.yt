
<?php
include("login.php"); 
if($_SESSION['loggedin']==true){
     header("location:loginindex.html");
 }

if($_SESSION['name']==''){
	header("location: signup.php");
}

?> 

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- <title>Document</title> -->
    <link rel="stylesheet" href="home.css">
    <link rel="stylesheet" href="profile.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <style>
        body {
            background-image: url('p.jpg');
            background-size: cover; 
            background-repeat: no-repeat; 
            background-attachment: fixed; 
        }

    </style>


</head>


<body>

    <header>
        <div class="logo">The <b style="color: #06C167;">WasteNot</b></div>
        <div class="hamburger">
            <div class="line"></div>
            <div class="line"></div>
            <div class="line"></div>
        </div>
        <nav class="nav-bar">
            <ul>
               
                <li><a href="profile.php"  class="active">Profile</a></li>
                <li><a href="fooddonateform.php"  class="active">Donate Food</a></li>
                <li><a href="money.php"  class="active">Donate Money</a></li>
            </ul>
        </nav>
    </header>
    <script>
        hamburger=document.querySelector(".hamburger");
        hamburger.onclick =function(){
            navBar=document.querySelector(".nav-bar");
            navBar.classList.toggle("active");
        }
    </script>

    <div class="profile">
        <div class="profilebox" style="height: 1100px;">
        <p class="headingline" style="text-align: left;font-size:30px;"> <img src="" alt="" style="width:40px; height:  height: 25px;; padding-right: 10px; position: relative;" >Profile</p>

        <img src="user.png" alt="" style="width: 90px; height: 90px; border-radius:50%; display: block; margin-left: auto; margin-right: auto; padding-top: 10px; border: 1px solid #06C167;">


            <p style="font-size: 28px;">welcome</p>
            <p style="color: black;"><?php echo"". $_SESSION['name'] ;?></p>
            <br>
            <div class="info" style="padding-left:10px;">
            <p style="">Name  :<?php echo"". $_SESSION['name'] ;?> </p><br>
            <p style="">Email :<?php echo"". $_SESSION['email'];?> </p><br>
            <p style="">Gender:<?php echo"". $_SESSION['gender'] ;?> </p><br>
            
            <a href="home.html" style="float: left;margin-top: 6px ;border-radius:5px; background-color: #06C167; color: white;padding: ;padding-left: 10px;padding-right: 10px;">Logout</a>
            </div>
            <br>

            <hr>

            <p class="heading">Your donations</p>

            <div class="table-container">
                <p id="heading">Food Donations</p>
                <div class="table-wrapper" style="max-height: 200px; overflow-y: auto; display: block;">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Food</th>
                                <th>Type</th>
                                <th>Category</th>
                                <th>Date/Time</th>
                                <th>Quantity (Kg)</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $email = $_SESSION['email'];
                            $query = "SELECT * FROM food_donations WHERE email = '$email'";
                            $result = mysqli_query($connection, $query);
                            if ($result == true) {
                                while ($row = mysqli_fetch_assoc($result)) {
                                    echo "<tr><td>" . $row['food'] . "</td><td>" . $row['type'] . "</td><td>" . $row['category'] . "</td><td>" . $row['date'] . "</td><td>" . $row['quantity'] . "</td></tr>";
                                }
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <div class="table-container">
                <p id="heading">Money Donations</p>
                <div class="table-wrapper" style="max-height: 200px; overflow-y: auto; display: block;">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Type</th>
                                <th>Payment Method</th>
                                <th>Amount</th>
                                <th>Date/Time</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $email = $_SESSION['email'];
                            $query = "SELECT * FROM donations WHERE email = '$email'";
                            $result = mysqli_query($connection, $query);
                            if ($result == true) {
                                while ($row = mysqli_fetch_assoc($result)) {
                                    echo "<tr><td>" . $row['name'] . "</td><td>" . $row['type'] . "</td><td>" . $row['payment_method'] . "</td><td>" . $row['amount'] . "</td><td>" . $row['date'] . "</td></tr>";
                                }
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</body>
</html>